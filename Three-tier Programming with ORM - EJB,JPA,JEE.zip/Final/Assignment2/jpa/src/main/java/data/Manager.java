package data;

public class Manager {
}
